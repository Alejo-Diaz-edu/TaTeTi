library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity DecoLuces is
	port 
	(
	-- INPUTS
		E1	   : in std_logic_vector (16 downto 1);
		E0	   : in std_logic_vector (16 downto 1);
		CLKBIT	: in std_logic;
		
	--E1E0
	-- 00 => Celda Vacía
	-- 01 => Jugador 1
	-- 10 => Jugador 2
	-- 11 => ""IA""
	
		ERROR : in std_logic_vector (16 downto 1); 
	-- SI HAY ERROR, ERROR => 1, sino, ERROR => 0. 
	-- Ejemplo: hay error en la celda 7: ERROR => 0000001000000000
		
	-- OUTPUTS (Incompleto)
	ControlBit : out std_logic;
	STOP	: out std_logic := '1'
	);

end entity;

architecture Design of DecoLuces is
type t_celdas is array (1 to 16) of std_logic_vector(1 downto 0);
signal Control : std_logic_vector (383 downto 0);
 
begin

	-- ESTE PROCESO ASIGNA LA ENTIDAD DE CADA CELDA Y SI PRESENTA ERROR
--	process ( E1, E0)
	
--	variable Celda : t_celdas;
	
--		begin
		
--			FOR i in 1 to 16 LOOP 
--					Celda(i) <= E1[i] & E2[i] & ERROR[i];
--			end loop;
		
--	end process;
	
--PRUEBA
Control <= "111111111111111100000000000000001111111111111111111111110000000011111111000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000000000001111111100000000111111111111111111111111000000001111111100000000111111111111111111111111";

process(CLKBIT)
    variable i : integer := 0;
begin

    if rising_edge(CLKBIT) then
        ControlBit <= Control(i);

        if i = 383 then
				STOP <= '0';
            i := 0;              -- vuelve a empezar
        else
				STOP <= '1';
            i := i + 1;
        end if;
    end if;
end process;

end Design;
