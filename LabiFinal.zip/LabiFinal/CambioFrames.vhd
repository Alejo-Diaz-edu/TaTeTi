library ieee;
use ieee.std_logic_1164.all;

entity CambioFrames is

	port(
		ClkFrame		 : in	std_logic;
		ClkBit : in std_logic;
		Reset	 : in	std_logic;
		Color : in std_logic_vector(23 downto 0);
		Output	 : out	std_logic;
		STOP	: out std_logic := '1'
	);

end entity;

architecture rtl of CambioFrames is

	-- Build an enumerated type for the state machine
	type state_type is (F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12, F13, F14);

	-- Register to hold the current state
	signal state   : state_type;
	
	signal Control : std_logic_vector(383 downto 0);
	
	signal Control_Anterior : std_logic_vector(383 downto 0);

begin

	-- Logic to advance to the next state
	process (ClkFrame, Reset)
	begin
		if reset = '1' then
			state <= F1;
		elsif (rising_edge(ClkFrame)) then
			case state is
			-- PANEO IZQUIERDA A DERECHA
				when F1 =>
				
					state <= F2;
					Control <= Color & Color & Color & Color & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000";

				when F2 =>
				
					state <= F3;
					Control <= x"000000" & x"000000" & x"000000" & x"000000" & Color & Color & Color & Color & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000";

				when F3 =>
				
					state <= F4;
					Control <= x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & Color & Color & Color & Color & x"000000" & x"000000" & x"000000" & x"000000";

				when F4 =>
				
					state <= F5;
					Control <= x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & x"000000" & Color & Color & Color & Color;
			-- PANEO ARRIBA A ABAJO
				when F5 =>
				
					state <= F6;
					Control <= Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000";
					
				when F6 =>
				
					state <= F7;
					Control <= x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000";
					
				when F7 =>
				
					state <= F8;
					Control <= x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000";
					
				when F8 =>
				
					state <= F9;
					Control <= x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color & x"000000" & x"000000" & x"000000" & Color;
			-- LETRAS  
				when F9 =>
				-- W
					state <= F10;
					Control <= x"000000" & Color & Color & Color & x"000000" & x"000000" & x"000000" & Color & Color & x"000000" & Color & Color & Color & Color & Color & x"000000";

				when F10 =>
				-- I
					state <= F11;
					Control <= Color & x"000000" & x"000000" & Color & Color & Color & Color & Color & Color & Color & Color & Color & Color & x"000000" & x"000000" & Color;

				when F11 =>
				-- N
					state <= F12;
					Control <= x"000000" & Color & Color & Color & Color & Color & Color & x"000000" & x"000000" & x"000000" & Color & Color & Color & Color & Color & Color;

				when F12 =>
				-- N
					state <= F13;
					Control <= x"000000" & Color & Color & Color & Color & Color & Color & x"000000" & x"000000" & x"000000" & Color & Color & Color & Color & Color & Color;

				when F13 =>
				-- E
					state <= F14;
					Control <= x"000000" & Color & Color & Color & Color & Color & Color & Color & Color & x"000000" & Color & Color & Color & x"000000" & x"000000" & Color;

				when F14 =>
				-- R
					state <= F1;
					Control <= x"000000" & Color & Color & Color & Color & Color & Color & Color & Color & x"000000" & Color & x"000000" & x"000000" & Color & x"000000" & Color;

			end case;
		end if;
	end process;

	-- Output depends solely on the current state
	process(ClkBit, Control)
    variable i : integer := 0;
begin

   if rising_edge(ClkBit) then
		if Control /= Control_Anterior then -- SI CONTROL NO CAMBIA, NO VUELVE A EMPEZAR
			Output <= Control(i);

			if i = 383 then
				STOP <= '0';
            i := 0;-- vuelve a empezar
				Control_Anterior <= Control; -- CUANDO TERMINA, CAMBIA EL CONTROL (BLOQUEA EL SISTEMA)
        else
				STOP <= '1';
            i := i + 1;
        end if;
    end if;
	end if;
end process;

end rtl;